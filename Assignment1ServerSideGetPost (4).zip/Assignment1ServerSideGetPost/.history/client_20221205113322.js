const URL = "https://localhost:9999/customer";

const fetchAPI = fetch(url);

fetchAPI.then