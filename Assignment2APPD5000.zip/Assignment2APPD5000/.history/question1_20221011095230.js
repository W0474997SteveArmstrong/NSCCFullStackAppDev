// This Assignment2 question1 tests the knowledge of readfilesync

//Here fs means file synchronus
const fs = require('fs');
const fileContents = fs.readFileSync("files/fileUsedForReading.txt")