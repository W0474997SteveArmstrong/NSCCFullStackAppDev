console.log("The Itsy Bitsy Aardvark");
console.log("");
console.log("Please choose an animal name:");
a