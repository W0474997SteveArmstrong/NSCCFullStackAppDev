// This Assignment2 question1 tests the knowledge of readfilesync

const rfs = require('readfile-sync')