console.log("The Itsy Bitsy Aardvark");
console.log("");
console.log("Please choose an animal name:");
console.log("a) aardvark");
console.log("b) hippo");
console.log("c) duck");
console.log("d) pelican");
console.log("e) t-rex");

const rls =require('readline-sync'); 
const choice = rls.question("Enter choice (a-e):");
if (choice) {
    
}