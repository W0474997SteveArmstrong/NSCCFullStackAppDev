exp
const RLS = require('readline-sync');