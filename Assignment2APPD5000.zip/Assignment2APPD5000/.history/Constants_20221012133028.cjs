export const RLS = require('readline-sync');
export const CHOICE = RLS.question("Enter choice (a-e):");