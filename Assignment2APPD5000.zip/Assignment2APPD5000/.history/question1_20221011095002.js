// This Assignment2 question1 tests the knowledge of readfilesync

//
const fs = require('readfile-sync');