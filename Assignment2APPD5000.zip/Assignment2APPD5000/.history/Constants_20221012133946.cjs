Using this file to maintain all the globally scoped constants of Assignment2
Question1 and Question2 in a single place.
const RLS = require('readline-sync');
const CHOICE = RLS.question("Enter choice (a-e):");